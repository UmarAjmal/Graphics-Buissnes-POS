<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\SaleReturn;
use App\Models\StockBatch;
use App\Models\StockMove;
use App\Models\StockAdjustment;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class InventoryService
{
    /**
     * Process purchase and create stock batches
     */
    public function receivePurchase(Purchase $purchase): void
    {
        DB::transaction(function () use ($purchase) {
            foreach ($purchase->purchaseItems as $item) {
                $product = $item->product;

                if ($product->type === 'simple') {
                    $this->createSimpleBatch($item);
                } elseif ($product->type === 'panaflex_roll') {
                    $this->createPanaflexBatch($item);
                }
            }
        });
    }

    /**
     * Create stock batch for simple product
     */
    private function createSimpleBatch($purchaseItem): void
    {
        $batch = StockBatch::create([
            'product_id' => $purchaseItem->product_id,
            'batch_no' => StockBatch::generateBatchNumber($purchaseItem->product),
            'purchase_item_id' => $purchaseItem->id,
            'qty_total' => $purchaseItem->quantity,
            'qty_remaining' => $purchaseItem->quantity,
            'received_at' => $purchaseItem->purchase->purchased_at->toDateString(),
        ]);

        $this->createStockMove(
            $purchaseItem->product_id,
            'purchase',
            $purchaseItem->purchase_id,
            'purchases',
            $batch->id,
            $purchaseItem->quantity,
            null,
            'Purchase received'
        );
    }

    /**
     * Create stock batch for panaflex roll
     */
    private function createPanaflexBatch($purchaseItem): void
    {
        $totalMeters = $purchaseItem->roll_length_meter * $purchaseItem->rolls_count;

        $batch = StockBatch::create([
            'product_id' => $purchaseItem->product_id,
            'batch_no' => StockBatch::generateBatchNumber($purchaseItem->product),
            'purchase_item_id' => $purchaseItem->id,
            'roll_width_inch' => $purchaseItem->roll_width_inch,
            'meters_total' => $totalMeters,
            'meters_remaining' => $totalMeters,
            'received_at' => $purchaseItem->purchase->purchased_at->toDateString(),
        ]);

        $this->createStockMove(
            $purchaseItem->product_id,
            'purchase',
            $purchaseItem->purchase_id,
            'purchases',
            $batch->id,
            null,
            $totalMeters,
            'Purchase received - ' . $purchaseItem->rolls_count . ' rolls'
        );
    }

    /**
     * Consume stock for sale (FIFO)
     */
    public function consumeForSale(Sale $sale): void
    {
        DB::transaction(function () use ($sale) {
            foreach ($sale->saleItems as $item) {
                $product = $item->product;

                if ($product->type === 'simple') {
                    $this->consumeSimpleStock($item, $sale);
                } elseif ($product->type === 'panaflex_roll') {
                    $this->consumePanaflexStock($item, $sale);
                }
            }
        });
    }

    /**
     * Consume simple product stock (FIFO)
     */
    private function consumeSimpleStock($saleItem, Sale $sale): void
    {
        $needed = $saleItem->quantity;
        $product = $saleItem->product;

        // Get available batches (FIFO - oldest first)
        $batches = StockBatch::where('product_id', $product->id)
            ->where('qty_remaining', '>', 0)
            ->orderBy('received_at')
            ->orderBy('id')
            ->get();

        foreach ($batches as $batch) {
            if ($needed <= 0) break;

            $take = min($batch->qty_remaining, $needed);
            
            $batch->update([
                'qty_remaining' => $batch->qty_remaining - $take
            ]);

            $this->createStockMove(
                $product->id,
                'sale',
                $sale->id,
                'sales',
                $batch->id,
                -$take,
                null,
                "Sale {$sale->invoice_no}"
            );

            $needed -= $take;
        }

        if ($needed > 0) {
            throw new \Exception("Insufficient stock for {$product->name}. Need {$needed} more units.");
        }
    }

    /**
     * Consume panaflex stock (FIFO)
     */
    private function consumePanaflexStock($saleItem, Sale $sale): void
    {
        $product = $saleItem->product;
        $rollWidthInch = $product->panaflexSpec->roll_width_inch;
        
        // Calculate meters needed using RollConsumptionService
        // Need to use the original length/width inputs from saleItem
        if (!$saleItem->length_input || !$saleItem->width_input) {
            throw new \Exception("Missing length/width inputs for panaflex sale item {$saleItem->id}");
        }
        
        $metersNeeded = RollConsumptionService::calcMetersUsed(
            $saleItem->length_input,
            $saleItem->length_unit ?? 'ft',
            $saleItem->width_input,
            $saleItem->width_unit ?? 'in',
            $rollWidthInch,
            $saleItem->quantity
        );

        // Get available batches with matching width (FIFO - oldest first)
        $batches = StockBatch::where('product_id', $product->id)
            ->where('roll_width_inch', $rollWidthInch)
            ->where('meters_remaining', '>', 0)
            ->orderBy('received_at')
            ->orderBy('id')
            ->get();

        $needed = $metersNeeded;
        foreach ($batches as $batch) {
            if ($needed <= 0) break;

            $take = min($batch->meters_remaining, $needed);
            
            $batch->update([
                'meters_remaining' => $batch->meters_remaining - $take
            ]);

            $this->createStockMove(
                $product->id,
                'sale',
                $sale->id,
                'sales',
                $batch->id,
                null,
                -$take,
                "Sale {$sale->invoice_no} - {$saleItem->units_sqft} sq.ft"
            );

            $needed -= $take;
        }

        if ($needed > 0) {
            throw new \Exception("Insufficient meters for {$product->name}. Need {$needed} more meters.");
        }
    }

    /**
     * Restock for return (LIFO backfill)
     */
    public function restockForReturn(SaleReturn $return): void
    {
        DB::transaction(function () use ($return) {
            foreach ($return->saleReturnItems as $returnItem) {
                $saleItem = $returnItem->saleItem;
                $product = $saleItem->product;

                if ($product->type === 'simple') {
                    $this->restockSimpleStock($returnItem, $return);
                } elseif ($product->type === 'panaflex_roll') {
                    $this->restockPanaflexStock($returnItem, $return);
                }
            }
        });
    }

    /**
     * Restock simple product (LIFO backfill)
     */
    private function restockSimpleStock($returnItem, SaleReturn $return): void
    {
        $product = $returnItem->saleItem->product;
        $qtyToRestock = $returnItem->quantity;

        // Get recently depleted batches (LIFO - newest first)
        $batches = StockBatch::where('product_id', $product->id)
            ->where('qty_total', '>', 'qty_remaining')
            ->orderBy('received_at', 'desc')
            ->orderBy('id', 'desc')
            ->get();

        $remaining = $qtyToRestock;
        foreach ($batches as $batch) {
            if ($remaining <= 0) break;

            $canRestore = $batch->qty_total - $batch->qty_remaining;
            $restore = min($canRestore, $remaining);

            $batch->update([
                'qty_remaining' => $batch->qty_remaining + $restore
            ]);

            $this->createStockMove(
                $product->id,
                'return',
                $return->id,
                'sale_returns',
                $batch->id,
                $restore,
                null,
                "Return {$return->return_no}"
            );

            $remaining -= $restore;
        }
    }

    /**
     * Restock panaflex stock (LIFO backfill)
     */
    private function restockPanaflexStock($returnItem, SaleReturn $return): void
    {
        $product = $returnItem->saleItem->product;
        $rollWidthInch = $product->panaflexSpec->roll_width_inch;
        
        // Calculate meters to restock
        $metersToRestock = RollConsumptionService::calcMetersUsed($returnItem->units_sqft, $rollWidthInch);

        // Get recently depleted batches with matching width (LIFO - newest first)
        $batches = StockBatch::where('product_id', $product->id)
            ->where('roll_width_inch', $rollWidthInch)
            ->where('meters_total', '>', 'meters_remaining')
            ->orderBy('received_at', 'desc')
            ->orderBy('id', 'desc')
            ->get();

        $remaining = $metersToRestock;
        foreach ($batches as $batch) {
            if ($remaining <= 0) break;

            $canRestore = $batch->meters_total - $batch->meters_remaining;
            $restore = min($canRestore, $remaining);

            $batch->update([
                'meters_remaining' => $batch->meters_remaining + $restore
            ]);

            $this->createStockMove(
                $product->id,
                'return',
                $return->id,
                'sale_returns',
                $batch->id,
                null,
                $restore,
                "Return {$return->return_no} - {$returnItem->units_sqft} sq.ft"
            );

            $remaining -= $restore;
        }
    }

    /**
     * Manual stock adjustment
     */
    public function adjust(Product $product, float $delta, ?int $batchId = null, string $reason = 'correction', ?string $note = null): void
    {
        

    /**
     * Get low stock products
     */
    public function getLowStockProducts(): array
    {
        $simpleProducts = Product::where('type', 'simple')
            ->whereNotNull('min_qty')
            ->with(['stockBatches'])
            ->get()
            ->filter(function ($product) {
                $totalQty = $product->stockBatches->sum('qty_remaining');
                return $totalQty <= $product->min_qty;
            });

        $panaflexProducts = Product::where('type', 'panaflex_roll')
            ->whereNotNull('min_meters')
            ->with(['stockBatches'])
            ->get()
            ->filter(function ($product) {
                $totalMeters = $product->stockBatches->sum('meters_remaining');
                return $totalMeters <= $product->min_meters;
            });

        return [
            'simple' => $simpleProducts,
            'panaflex' => $panaflexProducts,
        ];
    }

    /**
     * Get stock summary for a product
     */
    public function getStockSummary(Product $product): array
    {
        $batches = $product->stockBatches;

        if ($product->type === 'simple') {
            return [
                'total_qty' => $batches->sum('qty_total'),
                'remaining_qty' => $batches->sum('qty_remaining'),
                'available_batches' => $batches->where('qty_remaining', '>', 0)->count(),
                'is_low_stock' => $product->min_qty && $batches->sum('qty_remaining') <= $product->min_qty,
            ];
        } else {
            return [
                'total_meters' => $batches->sum('meters_total'),
                'remaining_meters' => $batches->sum('meters_remaining'),
                'available_batches' => $batches->where('meters_remaining', '>', 0)->count(),
                'is_low_stock' => $product->min_meters && $batches->sum('meters_remaining') <= $product->min_meters,
            ];
        }
    }

    /**
     * Create a stock move record
     */
    private function createStockMove(
        int $productId,
        string $type,
        ?int $refId,
        ?string $refTable,
        ?int $batchId,
        ?float $qtyChange,
        ?float $metersChange,
        ?string $note
    ): void {
        StockMove::create([
            'product_id' => $productId,
            'type' => $type,
            'ref_id' => $refId,
            'ref_table' => $refTable,
            'batch_id' => $batchId,
            'qty_change' => $qtyChange,
        

    /**
     * Get low stock products
     */
    public function getLowStockProducts(): array
    {
        $simpleProducts = Product::where('type', 'simple')
            ->whereNotNull('min_qty')
            ->with(['stockBatches'])
            ->get()
            ->filter(function ($product) {
                $totalQty = $product->stockBatches->sum('qty_remaining');
                return $totalQty <= $product->min_qty;
            });

        $panaflexProducts = Product::where('type', 'panaflex_roll')
            ->whereNotNull('min_meters')
            ->with(['stockBatches'])
            ->get()
            ->filter(function ($product) {
                $totalMeters = $product->stockBatches->sum('meters_remaining');
                return $totalMeters <= $product->min_meters;
            });

        return [
            'simple' => $simpleProducts,
            'panaflex' => $panaflexProducts,
        ];
    }

    /**
     * Get stock summary for a product
     */
    public function getStockSummary(Product $product): array
    {
        $batches = $product->stockBatches;

        if ($product->type === 'simple') {
            return [
                'total_qty' => $batches->sum('qty_total'),
                'remaining_qty' => $batches->sum('qty_remaining'),
                'available_batches' => $batches->where('qty_remaining', '>', 0)->count(),
                'is_low_stock' => $product->min_qty && $batches->sum('qty_remaining') <= $product->min_qty,
            ];
        } else {
            return [
                'total_meters' => $batches->sum('meters_total'),
                'remaining_meters' => $batches->sum('meters_remaining'),
                'available_batches' => $batches->where('meters_remaining', '>', 0)->count(),
                'is_low_stock' => $product->min_meters && $batches->sum('meters_remaining') <= $product->min_meters,
            ];
        }
    }

    /**
     * Create a stock move record
     */
    private function createStockMove(
        int $productId,
        string $type,
        ?int $refId,
        ?string $refTable,
        ?int $batchId,
        ?float $qtyChange,
        ?float $metersChange,
        ?string $note
    ): void {
        StockMove::create([
            'product_id' => $productId,
            'type' => $type,
            'ref_id' => $refId,
            'ref_table' => $refTable,
            'batch_id' => $batchId,
            'qty_change' => $qtyChange,
            'meters_change' => $metersChange,
            'user_id' => Auth::id(),
            'note' => $note,
        ]);
    }

    /**
     * Receive a specific purchase item and update inventory
     */
    public function receivePurchaseItem($purchaseItem, $quantity, $batchCode = null, $expiryDate = null): void
    {
        DB::transaction(function () use ($purchaseItem, $quantity, $batchCode, $expiryDate) {
            $product = $purchaseItem->product;

            // Create or update stock batch
            $batch = StockBatch::create([
                'product_id' => $product->id,
                'batch_no' => $batchCode ?: StockBatch::generateBatchNumber($product),
                'purchase_item_id' => $purchaseItem->id,
                'qty_total' => $quantity,
                'qty_remaining' => $quantity,
                'received_at' => now()->toDateString(),
                'expiry_date' => $expiryDate,
            ]);

            // Create stock movement record
            $this->createStockMove(
                $product->id,
                'purchase',
                $purchaseItem->id,
                'purchase_items',
                $batch->id,
                $quantity,
                0, // meters_change for simple products
                "Received purchase item - Batch: {$batch->batch_no}"
            );


            // Update product stock quantity
            $product->increment('stock_quantity', $quantity);
        });
    }
}

<!-- 🎨 Modern Icon Components Library -->

<!-- SVG Gradient Definitions (Include once in your main layout) -->
<svg width="0" height="0" style="position: absolute;">
  <defs>
    <linearGradient id="iconGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:var(--icon-color-primary);stop-opacity:1" />
      <stop offset="100%" style="stop-color:var(--icon-color-accent);stop-opacity:1" />
    </linearGradient>
    
    <linearGradient id="iconGradientAccent" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#06B6D4;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#3B82F6;stop-opacity:1" />
    </linearGradient>
    
    <!-- Glow filter for dark mode -->
    <filter id="iconGlow">
      <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
      <feMerge> 
        <feMergeNode in="coloredBlur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>
</svg>

<!-- Dashboard Icons Collection -->

<!-- Home/Dashboard Icon -->
<div class="icon-container icon-btn">
  <svg class="icon icon--primary" viewBox="0 0 24 24" fill="none">
    <path d="M3 9L12 2L21 9V20C21 20.5523 20.5523 21 20 21H4C3.44772 21 3 20.5523 3 20V9Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M9 22V12H15V22" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</div>

<!-- Analytics/Chart Icon -->
<div class="icon-container icon-btn">
  <svg class="icon icon--gradient" viewBox="0 0 24 24" fill="none">
    <path d="M3 3V21H21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M7 16L12 11L16 15L21 10" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="7" cy="16" r="1"/>
    <circle cx="12" cy="11" r="1"/>
    <circle cx="16" cy="15" r="1"/>
    <circle cx="21" cy="10" r="1"/>
  </svg>
</div>

<!-- Settings Icon with Rotation Animation -->
<div class="icon-container icon-btn" style="--icon-rotation: 90deg;">
  <svg class="icon icon--secondary" viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="3" stroke-width="2"/>
    <path d="M19.4 15C19.2669 15.3016 19.2272 15.6362 19.286 15.9606C19.3448 16.285 19.4995 16.5842 19.73 16.82L19.79 16.88C19.976 17.0657 20.1235 17.2863 20.2241 17.5291C20.3248 17.7719 20.3766 18.0322 20.3766 18.295C20.3766 18.5578 20.3248 18.8181 20.2241 19.0609C20.1235 19.3037 19.976 19.5243 19.79 19.71C19.6043 19.896 19.3837 20.0435 19.1409 20.1441C18.8981 20.2448 18.6378 20.2966 18.375 20.2966C18.1122 20.2966 17.8519 20.2448 17.6091 20.1441C17.3663 20.0435 17.1457 19.896 16.96 19.71L16.9 19.65C16.6642 19.4195 16.365 19.2648 16.0406 19.206C15.7162 19.1472 15.3816 19.1869 15.08 19.32C14.7842 19.4468 14.532 19.6572 14.3543 19.9255C14.1766 20.1938 14.0813 20.5082 14.08 20.83V21C14.08 21.5304 13.8693 22.0391 13.4942 22.4142C13.1191 22.7893 12.6104 23 12.08 23C11.5496 23 11.0409 22.7893 10.6658 22.4142C10.2907 22.0391 10.08 21.5304 10.08 21V20.91C10.0723 20.579 9.96512 20.258 9.77251 19.9887C9.5799 19.7194 9.31074 19.5143 9 19.4C8.69838 19.2669 8.36381 19.2272 8.03941 19.286C7.71502 19.3448 7.41568 19.4995 7.18 19.73L7.12 19.79C6.93425 19.976 6.71368 20.1235 6.47088 20.2241C6.22808 20.3248 5.96783 20.3766 5.705 20.3766C5.44217 20.3766 5.18192 20.3248 4.93912 20.2241C4.69632 20.1235 4.47575 19.976 4.29 19.79C4.10405 19.6043 3.95653 19.3837 3.85588 19.1409C3.75523 18.8981 3.70343 18.6378 3.70343 18.375C3.70343 18.1122 3.75523 17.8519 3.85588 17.6091C3.95653 17.3663 4.10405 17.1457 4.29 16.96L4.35 16.9C4.58054 16.6642 4.73519 16.365 4.794 16.0406C4.85282 15.7162 4.81312 15.3816 4.68 15.08C4.55324 14.7842 4.34276 14.532 4.07447 14.3543C3.80618 14.1766 3.49179 14.0813 3.17 14.08H3C2.46957 14.08 1.96086 13.8693 1.58579 13.4942C1.21071 13.1191 1 12.6104 1 12.08C1 11.5496 1.21071 11.0409 1.58579 10.6658C1.96086 10.2907 2.46957 10.08 3 10.08H3.09C3.42099 10.0723 3.742 9.96512 4.0113 9.77251C4.28059 9.5799 4.48572 9.31074 4.6 9C4.73312 8.69838 4.77282 8.36381 4.714 8.03941C4.65519 7.71502 4.50054 7.41568 4.27 7.18L4.21 7.12C4.02405 6.93425 3.87653 6.71368 3.77588 6.47088C3.67523 6.22808 3.62343 5.96783 3.62343 5.705C3.62343 5.44217 3.67523 5.18192 3.77588 4.93912C3.87653 4.69632 4.02405 4.47575 4.21 4.29C4.39575 4.10405 4.61632 3.95653 4.85912 3.85588C5.10192 3.75523 5.36217 3.70343 5.625 3.70343C5.88783 3.70343 6.14808 3.75523 6.39088 3.85588C6.63368 3.95653 6.85425 4.10405 7.04 4.29L7.1 4.35C7.33568 4.58054 7.63502 4.73519 7.95941 4.794C8.28381 4.85282 8.61838 4.81312 8.92 4.68H9C9.29577 4.55324 9.54802 4.34276 9.72569 4.07447C9.90337 3.80618 9.99872 3.49179 10 3.17V3C10 2.46957 10.2107 1.96086 10.5858 1.58579C10.9609 1.21071 11.4696 1 12 1C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V3.09C14.0013 3.41179 14.0966 3.72618 14.2743 3.99447C14.452 4.26276 14.7042 4.47324 15 4.6C15.3016 4.73312 15.6362 4.77282 15.9606 4.714C16.285 4.65519 16.5842 4.50054 16.82 4.27L16.88 4.21C17.0657 4.02405 17.2863 3.87653 17.5291 3.77588C17.7719 3.67523 18.0322 3.62343 18.295 3.62343C18.5578 3.62343 18.8181 3.67523 19.0609 3.77588C19.3037 3.87653 19.5243 4.02405 19.71 4.21C19.896 4.39575 20.0435 4.61632 20.1441 4.85912C20.2448 5.10192 20.2966 5.36217 20.2966 5.625C20.2966 5.88783 20.2448 6.14808 20.1441 6.39088C20.0435 6.63368 19.896 6.85425 19.71 7.04L19.65 7.1C19.4195 7.33568 19.2648 7.63502 19.206 7.95941C19.1472 8.28381 19.1869 8.61838 19.32 8.92V9C19.4468 9.29577 19.6572 9.54802 19.9255 9.72569C20.1938 9.90337 20.5082 9.99872 20.83 10H21C21.5304 10 22.0391 10.2107 22.4142 10.5858C22.7893 10.9609 23 11.4696 23 12C23 12.5304 22.7893 13.0391 22.4142 13.4142C22.0391 13.7893 21.5304 14 21 14H20.91C20.5882 14.0013 20.2738 14.0966 20.0055 14.2743C19.7372 14.452 19.5268 14.7042 19.4 15Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</div>

<!-- User Profile Icon -->
<div class="icon-container icon-btn">
  <svg class="icon icon--primary" viewBox="0 0 24 24" fill="none">
    <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="12" cy="7" r="4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</div>

<!-- Notification Bell with Badge -->
<div class="icon-container icon-btn icon-container--badge">
  <svg class="icon icon--secondary icon--pulse" viewBox="0 0 24 24" fill="none">
    <path d="M18 8C18 6.4087 17.3679 4.88258 16.2426 3.75736C15.1174 2.63214 13.5913 2 12 2C10.4087 2 8.88258 2.63214 7.75736 3.75736C6.63214 4.88258 6 6.4087 6 8C6 15 3 17 3 17H21C21 17 18 15 18 8Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M13.73 21C13.5542 21.3031 13.3019 21.5547 12.9982 21.7295C12.6946 21.9044 12.3504 21.9965 12 21.9965C11.6496 21.9965 11.3054 21.9044 11.0018 21.7295C10.6981 21.5547 10.4458 21.3031 10.27 21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</div>

<!-- Search Icon -->
<div class="icon-container icon-btn">
  <svg class="icon icon--secondary" viewBox="0 0 24 24" fill="none">
    <circle cx="11" cy="11" r="8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M21 21L16.65 16.65" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</div>

<!-- Theme Toggle Button -->
<button class="theme-toggle" id="themeToggle">
  <!-- Sun Icon (Light Mode) -->
  <svg class="icon sun-icon" viewBox="0 0 24 24" fill="none" style="display: block;">
    <circle cx="12" cy="12" r="5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M12 1V3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M12 21V23" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M4.22 4.22L5.64 5.64" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M18.36 18.36L19.78 19.78" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M1 12H3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M21 12H23" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M4.22 19.78L5.64 18.36" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M18.36 5.64L19.78 4.22" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
  
  <!-- Moon Icon (Dark Mode) -->
  <svg class="icon moon-icon" viewBox="0 0 24 24" fill="none" style="display: none;">
    <path d="M21 12.79C20.8427 14.4922 20.2039 16.1144 19.1583 17.4668C18.1127 18.8192 16.7035 19.8458 15.0957 20.4265C13.4879 21.0073 11.7473 21.1181 10.0713 20.746C8.39524 20.3739 6.84615 19.5345 5.63604 18.3244C4.42593 17.1143 3.58659 15.5652 3.21449 13.8892C2.84238 12.2132 2.95322 10.4726 3.53397 8.86482C4.11471 7.25699 5.14131 5.84779 6.49369 4.80219C7.84608 3.7566 9.46826 3.11731 11.1705 2.95996C9.98527 4.06932 9.26263 5.55661 9.13099 7.14226C8.99935 8.72791 9.46852 10.2951 10.4413 11.5522C11.414 12.8093 12.8184 13.6701 14.3967 13.9708C15.9749 14.2715 17.6135 14.0925 19.0652 13.4659C19.6652 13.2222 20.2292 12.8925 20.7412 12.4851C20.9086 12.5856 21.0702 12.6935 21.2251 12.8084C21.1531 12.7996 21.0808 12.7924 21.0082 12.7869C21.0029 12.7849 21.0029 12.7849 21 12.79Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</button>

<!-- Floating Action Button -->
<button class="icon-fab">
  <svg class="icon" viewBox="0 0 24 24" fill="none">
    <path d="M12 5V19" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M5 12H19" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</button>

<!-- Menu/Hamburger Icon with Glass Effect -->
<div class="icon-container icon-btn icon-glass">
  <svg class="icon icon--primary" viewBox="0 0 24 24" fill="none">
    <path d="M3 12H21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M3 6H21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M3 18H21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</div>

<!-- Loading Spinner -->
<div class="icon-container icon-loading">
  <svg class="icon icon--spin" viewBox="0 0 24 24" fill="none">
    <path d="M21 12C21 16.9706 16.9706 21 12 21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" opacity="0.3"/>
  </svg>
</div>

<!-- Heart/Like Icon with Micro Animation -->
<div class="icon-container icon-btn">
  <svg class="icon icon--accent icon-micro" viewBox="0 0 24 24" fill="none">
    <path d="M20.84 4.61C20.3292 4.099 19.7228 3.69364 19.0554 3.41708C18.3879 3.14052 17.6725 2.99817 16.95 2.99817C16.2275 2.99817 15.5121 3.14052 14.8446 3.41708C14.1772 3.69364 13.5708 4.099 13.06 4.61L12 5.67L10.94 4.61C9.9083 3.5783 8.50903 2.9987 7.05 2.9987C5.59096 2.9987 4.19169 3.5783 3.16 4.61C2.1283 5.6417 1.5487 7.04097 1.5487 8.5C1.5487 9.95903 2.1283 11.3583 3.16 12.39L12 21.23L20.84 12.39C21.351 11.8792 21.7563 11.2728 22.0329 10.6053C22.3095 9.93789 22.4518 9.22248 22.4518 8.5C22.4518 7.77752 22.3095 7.06211 22.0329 6.39467C21.7563 5.72723 21.351 5.1208 20.84 4.61Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</div>
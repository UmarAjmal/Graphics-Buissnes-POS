<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <title inertia>{{ config('app.name', 'Laravel') }}</title>

    @php
        $favicon = asset('favicon.ico');
        try {
            $companySettings = \App\Models\CompanySetting::current();
            if ($companySettings && $companySettings->logo_url) {
                $favicon = $companySettings->logo_url;
            }
        } catch (\Exception $e) {
            // Database might be down or not migrated yet, fallback to default favicon
        }
    @endphp
    <link rel="icon" href="{{ $favicon }}">
    
    <!-- Scripts -->
    @routes
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @inertiaHead
</head>
<body class="font-sans antialiased">
    @inertia
</body>
</html>